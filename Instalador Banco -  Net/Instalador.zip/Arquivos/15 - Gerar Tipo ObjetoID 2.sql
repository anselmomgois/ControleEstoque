QUERYVALIDACAO select 1 from systypes where name='OBJETO_ID'
BANCODEDADOS INFORMATIZ
create type OBJETO_ID from varchar(36)
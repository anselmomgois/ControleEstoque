QUERYVALIDACAO select 1 from systypes where name='CODIGO20'
BANCODEDADOS INFORMATIZ
create type CODIGO20 from varchar(20)
QUERYVALIDACAO select 1 from systypes where name='LOGICO'
BANCODEDADOS INFORMATIZ
create type LOGICO from bit
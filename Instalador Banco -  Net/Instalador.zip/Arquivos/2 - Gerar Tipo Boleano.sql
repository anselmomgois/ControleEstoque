QUERYVALIDACAO select 1 from systypes where name='BOLEANO'
BANCODEDADOS INFORMATIZ
create type BOLEANO 
from bit
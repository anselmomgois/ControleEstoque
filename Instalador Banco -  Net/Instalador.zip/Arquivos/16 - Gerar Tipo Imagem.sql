QUERYVALIDACAO select 1 from systypes where name='OBJETO_IMAGEM'
BANCODEDADOS INFORMATIZ
create type OBJETO_IMAGEM from image
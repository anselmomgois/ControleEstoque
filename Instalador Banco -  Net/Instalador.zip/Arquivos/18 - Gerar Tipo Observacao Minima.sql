QUERYVALIDACAO select 1 from systypes where name='OBSERVACAOMIN'
BANCODEDADOS INFORMATIZ
create type OBSERVACAOMIN from varchar(500)
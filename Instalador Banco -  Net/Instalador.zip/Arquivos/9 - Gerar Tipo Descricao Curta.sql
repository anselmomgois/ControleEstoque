QUERYVALIDACAO select 1 from systypes where name='DESCRICAO_CURTA'
BANCODEDADOS INFORMATIZ
create type DESCRICAO_CURTA from varchar(50)
QUERYVALIDACAO select 1 FROM INFM_ACAO WHERE CODACAO = '3'
BANCODEDADOS INFORMATIZ
INSERT INTO INFM_ACAO
           (IDACAO
           ,CODACAO
           ,DESACAO)
     VALUES
           ('3'
           ,'3'
           ,'Consultar')
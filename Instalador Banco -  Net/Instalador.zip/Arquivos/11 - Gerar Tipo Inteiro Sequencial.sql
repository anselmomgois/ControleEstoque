QUERYVALIDACAO select 1 from systypes where name='INTEIROSEQ'
BANCODEDADOS INFORMATIZ
create type INTEIROSEQ from integer not null
QUERYVALIDACAO select 1 from systypes where name='INTEIRO'
BANCODEDADOS INFORMATIZ
create type INTEIRO from integer
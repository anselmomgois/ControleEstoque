QUERYVALIDACAO select 1 from systypes where name='DESCRICAO50'
BANCODEDADOS INFORMATIZ
create type DESCRICAO50 from varchar(50)
QUERYVALIDACAO select 1 FROM INFM_ACAO WHERE CODACAO = '1'
BANCODEDADOS INFORMATIZ
INSERT INTO INFM_ACAO
           (IDACAO
           ,CODACAO
           ,DESACAO)
     VALUES
           ('1'
           ,'1'
           ,'Inserir')
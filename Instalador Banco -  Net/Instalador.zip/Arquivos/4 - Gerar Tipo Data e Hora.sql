QUERYVALIDACAO select 1 from systypes where name='DATAHORA'
BANCODEDADOS INFORMATIZ
create type DATAHORA from datetime
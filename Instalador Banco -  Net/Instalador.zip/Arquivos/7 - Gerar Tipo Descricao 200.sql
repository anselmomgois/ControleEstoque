QUERYVALIDACAO select 1 from systypes where name='DESCRICAO200'
BANCODEDADOS INFORMATIZ
create type DESCRICAO200 from varchar(200)
QUERYVALIDACAO select 1 from systypes where name='OBJETOID'
BANCODEDADOS INFORMATIZ
create type OBJETOID from varchar(36)
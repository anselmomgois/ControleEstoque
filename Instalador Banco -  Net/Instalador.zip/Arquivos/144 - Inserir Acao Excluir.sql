QUERYVALIDACAO select 1 FROM INFM_ACAO WHERE CODACAO = '4'
BANCODEDADOS INFORMATIZ
INSERT INTO INFM_ACAO
           (IDACAO
           ,CODACAO
           ,DESACAO)
     VALUES
           ('4'
           ,'4'
           ,'Excluir')
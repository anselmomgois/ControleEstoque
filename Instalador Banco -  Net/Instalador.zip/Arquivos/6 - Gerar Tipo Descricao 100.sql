QUERYVALIDACAO select 1 from systypes where name='DESCRICAO100'
BANCODEDADOS INFORMATIZ
create type DESCRICAO100 from varchar(100)
QUERYVALIDACAO select 1 FROM INFM_EMPRESA WHERE IDEMPRESA = 1
BANCODEDADOS INFORMATIZ
INSERT INTO INFM_EMPRESA
           (IDEMPRESA
           ,CODEMPRESA
           ,DESEMPRESA
           ,DESCNPJ
           ,DESINSCRICAOESTADUAL
           ,CODACESSO)
     VALUES
           (1
           ,1000
           ,'EMPRESA DEFAULT'
           ,NULL
           ,NULL
           ,'1')
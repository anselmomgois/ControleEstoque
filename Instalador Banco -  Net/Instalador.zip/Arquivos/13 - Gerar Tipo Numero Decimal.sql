QUERYVALIDACAO select 1 from systypes where name='NUMERO_DECIMAL'
BANCODEDADOS INFORMATIZ
create type NUMERO_DECIMAL from decimal(8,2)
QUERYVALIDACAO select 1 from systypes where name='DECIMAL1'
BANCODEDADOS INFORMATIZ
create type DECIMAL1 from decimal(8,2)
QUERYVALIDACAO select 1 FROM INFM_ACAO WHERE CODACAO = '2'
BANCODEDADOS INFORMATIZ
INSERT INTO INFM_ACAO
           (IDACAO
           ,CODACAO
           ,DESACAO)
     VALUES
           ('2'
           ,'2'
           ,'Modificar')
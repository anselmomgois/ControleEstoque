QUERYVALIDACAO select 1 from systypes where name='OBSERVACAOLONGA'
BANCODEDADOS INFORMATIZ
create type OBSERVACAOLONGA from varchar(Max)